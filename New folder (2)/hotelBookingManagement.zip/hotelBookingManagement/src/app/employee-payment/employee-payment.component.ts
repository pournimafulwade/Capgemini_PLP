import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee-payment',
  templateUrl: './employee-payment.component.html',
  styleUrls: ['./employee-payment.component.css']
})
export class EmployeePaymentComponent implements OnInit {
  userDetails = null;
  totalBill = null;
  successMessage = null;
  constructor(private roomservice: RoomService) {
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.userDetails = userdata;
    this.roomservice.totalBill(userdata.userId).subscribe(data => {
      console.log(data);
      this.totalBill = data.price;
      console.log(data.price);
    });
  }
  doPayment(paymentForm: NgForm) {
    console.log(paymentForm.value);
    if (paymentForm.value) {
      this.successMessage = 'Payment SuccessFul';
    }
  }
  ngOnInit() {
  }

}
