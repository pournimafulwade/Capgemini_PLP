import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-visitor',
  templateUrl: './visitor.component.html',
  styleUrls: ['./visitor.component.css']
})
export class VisitorComponent implements OnInit {
  hoteldetails: any[];
  localHotel = null;
  viewroom = null;
  viewroomdata = null;
  constructor(private hotelservice: HotelService, private roomservie: RoomService, private router: Router) {
    this.viewUserHotel();
  }

  viewUserHotel() {
    this.hotelservice.viewhotel().subscribe(data => {
      console.log(data);
      this.hoteldetails = data.hotelList;
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
