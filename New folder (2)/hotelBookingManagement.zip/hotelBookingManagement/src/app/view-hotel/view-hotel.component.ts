import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-view-hotel',
  templateUrl: './view-hotel.component.html',
  styleUrls: ['./view-hotel.component.css']
})
export class ViewHotelComponent implements OnInit {
  errorMessage = null;
  successMessage = null;
  viewHotellist: any[];
  viewhoteldata = null;

  //hotellist: any;
  hotellist = {
    hotelId: null,
    hotelName: null,
    location: null,
    imgURL: null
  };
  constructor(private hotelservice: HotelService, private roomservice: RoomService) {
    this.viewHotel();
  }

  viewHotel() {
    this.hotelservice.viewhotel().subscribe(data => {
      console.log(data);
      this.viewHotellist = data.hotelList;
    }, err => {
      console.log(err);
    });

  }

  deleteHotel(hoteldata) {
    this.hotelservice.deletehotel(hoteldata).subscribe(data => {
      console.log(data);
      this.viewHotel();
      this.successMessage = 'Hotel Deleted SuccessFully';
    }, err => {
      console.log(err);
      this.errorMessage = 'Unable to Delete Hotel Details';
    });
  }

  searchHotel(search) {
    this.hotelservice.searchhotel(search).subscribe(data => {
      console.log(data);

    });
  }
  viewRoom(room) {
    this.roomservice.viewroom(room).subscribe(data => {
      console.log(data);
    });
  }
  updateHotel(updateHotelForm: NgForm) {
    this.hotelservice.updatehotel(updateHotelForm.value).subscribe(data => {
      console.log(data);
      if (data && data.statusCode === 201) {
        this.successMessage = data.description;
      } else {
        this.errorMessage = data.description;
      }
    }, err => {
      console.log(err);
    });
  }
  update(hoteldata) {
    this.hotellist = hoteldata;
    //this.updateHotel(hoteldata);
    //console.log(this.hotellist);
  }
  ngOnInit() {
  }

}
