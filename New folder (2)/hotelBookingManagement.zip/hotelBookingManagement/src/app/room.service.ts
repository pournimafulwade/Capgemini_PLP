import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  hotelid;
  room;
  url = `http://localhost:8080`;

  constructor(private http: HttpClient) {
    const userdata = JSON.parse(localStorage.getItem('userdata'));

  }

  addroom(room): Observable<any> {
    return this.http.put<any>(`${this.url}/addRoom`, room);
  }
  viewroom(hotelId): Observable<any> {
    this.hotelid = hotelId;
    return this.http.get<any>(`${this.url}/getRoom1?hotelId=${hotelId}`);
  }
  getroom(room): Observable<any> {
    return this.http.get<any>(`${this.url}/getRoomList`, room);
  }
  deleteRoom(room): Observable<any> {
    return this.http.delete<any>(`${this.url}/deleteRoom?roomId=${room.roomId}`, room);
  }
  updateRoom(room): Observable<any> {
    return this.http.post<any>(`${this.url}/updateRoom`, room);
  }

  bookRoom(room): Observable<any> {
    return this.http.put<any>(`${this.url}/booking`, room);
  }
  totalBill(userId): Observable<any> {
    return this.http.get<any>(`${this.url}/totalBill?userId=${userId}`);
  }
  viewUserRoom(userName): Observable<any> {
    return this.http.get<any>(`${this.url}/viewStatus?userName=${userName}`);
  }
  cancelRoom(bookingId): Observable<any> {
    return this.http.delete<any>(`${this.url}/deleteStatus?bookingId=${bookingId}`);
  }
  gueststatus(hotelId): Observable<any> {
    return this.http.get<any>(`${this.url}/guestListOfSpecificHotel?hotelId=${hotelId}`);
  }
}
