import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-employee-status',
  templateUrl: './employee-status.component.html',
  styleUrls: ['./employee-status.component.css']
})
export class EmployeeStatusComponent implements OnInit {

  userDetails = null;
  viewroomdata = null;
  constructor(private roomservice: RoomService) {
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.userDetails = userdata;
    console.log(this.userDetails);
    console.log(this.userDetails.userName);
    this.roomservice.viewUserRoom(this.userDetails.userName).subscribe(data => {
      console.log(data);
      this.viewroomdata = data.bookingList;
      console.log(this.viewroomdata);
    });
  }

  ngOnInit() {
  }

}
