import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-hotel',
  templateUrl: './employee-hotel.component.html',
  styleUrls: ['./employee-hotel.component.css']
})
export class EmployeeHotelComponent implements OnInit {

  employeedetails = null;
  viewroomdata = null;
  constructor(private userservice: UserService, private roomservice: RoomService, private router: Router) {
    const userDetails = JSON.parse(localStorage.getItem('userdata'));
    this.employeedetails = userDetails;
    console.log(this.employeedetails.hotelId);
    this.employeeHotel(this.employeedetails.hotelId);
  }

  employeeHotel(hotelId) {
    this.roomservice.viewroom(hotelId).subscribe(data => {
      this.viewroomdata = data.roomList;
      console.log(data.roomList);
    });
  }

  bookRoom(roomdata) {
    console.log(roomdata);
    const room = localStorage.setItem('roomdetails', JSON.stringify(roomdata));
    this.router.navigateByUrl('/bookEmployeeroom');

  }

  ngOnInit() {
  }

}
