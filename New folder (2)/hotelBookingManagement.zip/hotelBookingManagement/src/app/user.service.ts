import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = `http://localhost:8080`;
  constructor(private http: HttpClient) { }

  login(user): Observable<any> {
    return this.http.get<any>(`${this.url}/userLogin?userEmail=${user.userEmail}&userPassword=${user.userPassword}`, user);
  }
  register(user): Observable<any> {
    return this.http.post<any>(`${this.url}/userRegistration`, user);
  }
  updateuserProfile(user): Observable<any> {
    return this.http.post<any>(`${this.url}/updateUserProfile`, user);
  }
  getUser(user): Observable<any> {
    return this.http.get<any>(`${this.url}/getAllUsers`, user);
  }
  getEmployee(user): Observable<any> {
    return this.http.get<any>(`${this.url}/getAllEmployee`, user);
  }
  bookinglist(list): Observable<any> {
    return this.http.get<any>(`${this.url}/bookingList`, list);
  }
}
