import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {

  userdetails = null;
  constructor(private userservice: UserService) {
    this.getallUser(userservice);
  }

  getallUser(user) {
    this.userservice.getUser(user).subscribe(data => {
      console.log(data);
      this.userdetails = data.userList;
    });
  }
  ngOnInit() {
  }

}
