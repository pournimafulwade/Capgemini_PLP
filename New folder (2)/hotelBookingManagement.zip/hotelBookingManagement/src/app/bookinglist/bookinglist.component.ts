import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-bookinglist',
  templateUrl: './bookinglist.component.html',
  styleUrls: ['./bookinglist.component.css']
})
export class BookinglistComponent implements OnInit {

  bookeddata: any[];
  constructor(private userservice: UserService) {
    this.userservice.bookinglist(userservice).subscribe(data => {
      console.log(data);
      this.bookeddata = data.bookingList;
    });
  }

  ngOnInit() {
  }

}
