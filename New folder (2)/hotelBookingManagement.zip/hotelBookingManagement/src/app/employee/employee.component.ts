import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  viewprofile = null;
  constructor(private userservice: UserService) {
    const userDetails = JSON.parse(localStorage.getItem('userdata'));
    this.viewprofile = userDetails;
  }

  ngOnInit() {
  }

}
