import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datelist',
  templateUrl: './datelist.component.html',
  styleUrls: ['./datelist.component.css']
})
export class DatelistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
