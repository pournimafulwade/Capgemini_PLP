import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-add-hotel',
  templateUrl: './add-hotel.component.html',
  styleUrls: ['./add-hotel.component.css']
})
export class AddHotelComponent implements OnInit {

  error = null;
  errorMessage = null;
  successMessage = null;
  hoteldetails: [];
  hoteldetail = null;

  constructor(private hotelservice: HotelService, private roomservice: RoomService) { }

  addHotel(addHotelForm: NgForm) {
    this.hotelservice.addhotel(addHotelForm.value).subscribe(data => {
      console.log(data);
      this.hoteldetails = data;
      console.log(this.hoteldetails);
      this.errorMessage = null;
      this.successMessage = data.description;

      addHotelForm.reset();
    }, err => {
      console.log(err);
    });
  }

  addRoom(addRoomForm: NgForm) {
    // const hotelinfo = JSON.parse(localStorage.getItem('hoteldata'));
    console.log(addRoomForm.value);
    this.roomservice.addroom(addRoomForm.value).subscribe(data => {
      console.log(data);
      if (data && data.statusCode === 201) {
        this.successMessage = data.description;
      } else if (data && data.statusCode === 401) {
        this.error = data.description;
      }
      addRoomForm.reset();
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
