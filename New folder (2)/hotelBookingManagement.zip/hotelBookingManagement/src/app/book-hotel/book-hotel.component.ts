import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-book-hotel',
  templateUrl: './book-hotel.component.html',
  styleUrls: ['./book-hotel.component.css']
})
export class BookHotelComponent implements OnInit {

  roomdetails = null;
  user = null;
  totalbill = null;
  constructor(private roomservice: RoomService, private router: Router) {
    const roomdata = JSON.parse(localStorage.getItem('roomdetails'));
    console.log(roomdata);
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.roomdetails = roomdata;
    this.user = userdata;
  }

  bookRoom(bookRoomForm: NgForm) {
    console.log(bookRoomForm.value);
    console.log(this.user.userId);
    this.roomservice.bookRoom(bookRoomForm.value).subscribe(data => {
      const userDetails = localStorage.setItem('roombooking', JSON.stringify(data));
      console.log(localStorage.getItem('roombooking'));
      this.router.navigateByUrl('/payment');
      this.totalbill = data.price;
    });
  }

  ngOnInit() {
  }

}
