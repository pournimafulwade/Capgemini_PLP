import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchhotelName'
})
export class SearchhotelNamePipe implements PipeTransform {

  transform(hotels: any[], search: string): any[] {
    if (search === undefined) {
      return hotels;
    } else {
      return hotels.filter(hotel => {
        return (hotel.hotelName as string).toLowerCase().includes(search.toLowerCase());
      });
    }
  }
}
