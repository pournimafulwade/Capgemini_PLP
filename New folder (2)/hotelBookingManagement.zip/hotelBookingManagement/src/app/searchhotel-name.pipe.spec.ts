import { SearchhotelNamePipe } from './searchhotel-name.pipe';

describe('SearchhotelNamePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchhotelNamePipe();
    expect(pipe).toBeTruthy();
  });
});
