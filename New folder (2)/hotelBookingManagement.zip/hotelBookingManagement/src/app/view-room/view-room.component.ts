import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-view-room',
  templateUrl: './view-room.component.html',
  styleUrls: ['./view-room.component.css']
})
export class ViewRoomComponent implements OnInit {

  roomdetails: any[];
  roomlist = {
    roomId: null,
    roomRent: null,
    roomType: null,
    roomCapacity: null,
    roomStatus: null,
    hotelId: null,
    imgURL: null
  };
  updateMessage = null;
  constructor(private roomservice: RoomService) {
    this.getroomdata(roomservice);
  }

  getroomdata(room) {
    this.roomservice.getroom(room).subscribe(data => {
      console.log(data);
      this.roomdetails = data.roomList;
    });
  }
  deleteRoom(roomdata) {
    this.roomservice.deleteRoom(roomdata).subscribe(data => {
      console.log(data);
      this.getroomdata(data);
    });
  }

  updateRoom(updateRoomForm: NgForm) {
    this.roomservice.updateRoom(updateRoomForm.value).subscribe(data => {
      console.log(data);
      this.updateMessage = data.description;
    });
  }
  updateData(roomdata) {
    this.roomlist = roomdata;
  }
  ngOnInit() {
  }

}
