import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  error = null;
  viewprofile = null;
  constructor(private userservice: UserService) {
    const userDetails = JSON.parse(localStorage.getItem('userdata'));
    this.viewprofile = userDetails;
  }

  updateUser(updateprofile: NgForm) {
    this.userservice.updateuserProfile(updateprofile.value).subscribe(data1 => {
      console.log(data1);
      this.error = data1.description;
      updateprofile.reset();
    }, err => {
      console.log(err);

    });
  }

  ngOnInit() {
  }

}
