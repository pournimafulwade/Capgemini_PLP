import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { EmployeeComponent } from './employee/employee.component';
import { HttpClientModule } from '@angular/common/http';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { ViewHotelComponent } from './view-hotel/view-hotel.component';
import { ViewRoomComponent } from './view-room/view-room.component';
import { ViewUserhotelComponent } from './view-userhotel/view-userhotel.component';
import { ViewUserroomComponent } from './view-userroom/view-userroom.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { BookHotelComponent } from './book-hotel/book-hotel.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeHotelComponent } from './employee-hotel/employee-hotel.component';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { SearchLocationPipe } from './search-location.pipe';
import { PaymentComponent } from './payment/payment.component';
import { ViewBookRoomComponent } from './view-book-room/view-book-room.component';
import { BookEmployeeComponent } from './book-employee/book-employee.component';
import { EmployeePaymentComponent } from './employee-payment/employee-payment.component';
import { ServicesComponent } from './services/services.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { BookinglistComponent } from './bookinglist/bookinglist.component';
import { GuestlistComponent } from './guestlist/guestlist.component';
import { DatelistComponent } from './datelist/datelist.component';
import { SearchhotelNamePipe } from './searchhotel-name.pipe';
import { EmployeeStatusComponent } from './employee-status/employee-status.component';
import { FooterComponent } from './footer/footer.component';
import { VisitorComponent } from './visitor/visitor.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    AdminComponent,
    UserComponent,
    EmployeeComponent,
    AddHotelComponent,
    ViewHotelComponent,
    ViewRoomComponent,
    ViewUserhotelComponent,
    ViewUserroomComponent,
    ViewProfileComponent,
    DashboardComponent,
    UserDashboardComponent,
    ViewUserComponent,
    ViewEmployeeComponent,
    BookHotelComponent,
    AddEmployeeComponent,
    EmployeeHotelComponent,
    EmployeeProfileComponent,
    SearchLocationPipe,
    PaymentComponent,
    ViewBookRoomComponent,
    BookEmployeeComponent,
    EmployeePaymentComponent,
    ServicesComponent,
    ContactUsComponent,
    BookinglistComponent,
    GuestlistComponent,
    DatelistComponent,
    SearchhotelNamePipe,
    EmployeeStatusComponent,
    FooterComponent,
    VisitorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
