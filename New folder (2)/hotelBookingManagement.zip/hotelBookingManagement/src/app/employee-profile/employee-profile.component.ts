import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-employee-profile',
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.css']
})
export class EmployeeProfileComponent implements OnInit {
  error = null;
  viewprofile = null;
  constructor(private userservice: UserService) {
    const userDetails = JSON.parse(localStorage.getItem('userdata'));
    this.viewprofile = userDetails;
  }

  updateUser(updateprofile: NgForm) {
    this.userservice.updateuserProfile(updateprofile.value).subscribe(data => {
      console.log(data);
      this.error = data.description;
      this.error = 'Employee Details Updated Successfully';
      updateprofile.reset();
    }, err => {
      console.log(err);

    });
  }


  ngOnInit() {
  }

}
