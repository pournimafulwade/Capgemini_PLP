import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  error = null;
  message: any[];
  errorMessage = null;
  successMessage = null;
  constructor(private userservice: UserService, private router: Router) { }

  loginUser(loginForm: NgForm) {
    this.error = null;
    console.log(loginForm.value);
    this.userservice.login(loginForm.value).subscribe(data => {
      this.errorMessage = null;
      console.log(data);
      if (data && data.statusCode === 201) {
        this.successMessage = 'Login Successful';
        localStorage.setItem('userdata', JSON.stringify(data.userBean));
        if (data && data.userBean.userType === 'admin') {
          this.router.navigateByUrl('/admin');
        } else if (data && data.userBean.userType === 'user') {
          this.router.navigateByUrl('/viewuserhotel');
        } else if (data && data.userBean.userType === 'employee') {
          this.router.navigateByUrl('/employeehotel');
        }
      } else if (data && data.statusCode === 401) {
        this.error = data.description;
        this.errorMessage = 'User Email or password Wrong!!Please try again';
      }
      const userDetails = localStorage.setItem('userdata', JSON.stringify(data.userBean));
    }, err => {
      console.log(err);
      this.error = err.error.errror.message;

    });
    loginForm.reset();
  }

  ngOnInit() {
  }

}
