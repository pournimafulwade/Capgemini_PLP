import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUserroomComponent } from './view-userroom.component';

describe('ViewUserroomComponent', () => {
  let component: ViewUserroomComponent;
  let fixture: ComponentFixture<ViewUserroomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewUserroomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUserroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
