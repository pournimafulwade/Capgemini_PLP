import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-userroom',
  templateUrl: './view-userroom.component.html',
  styleUrls: ['./view-userroom.component.css']
})
export class ViewUserroomComponent implements OnInit {

  viewroomdata: any[];
  localHotel = null;
  constructor(private roomservice: RoomService, private router: Router) {
    const roomdata = JSON.parse(localStorage.getItem('roomdetails'));
    this.viewroomdata = roomdata;
  }


  hotel(hotelForm: NgForm) {
    this.roomservice.viewroom(hotelForm.value).subscribe(data => {
      console.log(data);
      this.viewroomdata = data.roomList;
      const hotels = localStorage.setItem('hoteldata', JSON.stringify('data.hotelList'));
      this.localHotel = hotels;
      console.log(this.localHotel);
    });
  }

  bookRoom(roomdata) {
    console.log(roomdata);
    const room = localStorage.setItem('roomdetails', JSON.stringify(roomdata));
    this.router.navigateByUrl('/bookroom');

  }

  ngOnInit() {
  }

}
