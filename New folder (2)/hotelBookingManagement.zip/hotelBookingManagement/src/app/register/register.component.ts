import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user = 'user';

  error = null;
  errorMessage = null;
  successMessage = null;
  constructor(private userservice: UserService) { }

  registerUser(registerForm: NgForm) {
    console.log(registerForm.value);
    this.userservice.register(registerForm.value).subscribe(data => {
      console.log(data);
      if (data && data.statusCode === 201) {
        this.error = data.description;
        this.successMessage = 'User Registration Successful!!Please Login to proceed further';
      } else if (data && data.statusCode === 401) {
        this.error = data.description;
        this.errorMessage = 'User Already Registered';
      }
      registerForm.reset();
    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

}
