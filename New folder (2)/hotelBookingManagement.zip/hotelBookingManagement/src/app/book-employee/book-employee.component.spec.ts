import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookEmployeeComponent } from './book-employee.component';

describe('BookEmployeeComponent', () => {
  let component: BookEmployeeComponent;
  let fixture: ComponentFixture<BookEmployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookEmployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookEmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
