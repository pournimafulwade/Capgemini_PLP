import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-employee',
  templateUrl: './book-employee.component.html',
  styleUrls: ['./book-employee.component.css']
})
export class BookEmployeeComponent implements OnInit {
  roomdetails = null;
  user = null;
  totalbill = null;
  constructor(private roomservice: RoomService, private router: Router) {
    const roomdata = JSON.parse(localStorage.getItem('roomdetails'));
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.roomdetails = roomdata;
    this.user = userdata;
  }

  bookRoom(bookRoomForm: NgForm) {
    console.log(bookRoomForm.value);
    console.log(this.user.userId);
    this.roomservice.bookRoom(bookRoomForm.value).subscribe(data => {
      const userDetails = localStorage.setItem('roombooking', JSON.stringify(data));
      console.log(localStorage.getItem('roombooking'));
      this.router.navigateByUrl('/employeepayment');
      this.totalbill = data.price;
    });
  }

  ngOnInit() {
  }

}
