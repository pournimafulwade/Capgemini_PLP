// interface Hotel {

// }