import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  userDetails = null;
  totalBill = null;
  successMessage = null;
  constructor(private roomservice: RoomService) {
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.userDetails = userdata;
    console.log(this.userDetails);
    const roomdetails = JSON.parse(localStorage.getItem('roombooking'));
    console.log(roomdetails);
    console.log(this.userDetails.userId);
    this.roomservice.totalBill(this.userDetails.userId).subscribe(data => {
      console.log(data);
      this.totalBill = data.price;
      console.log(this.totalBill);
    });
  }
  doPayment(paymentForm: NgForm) {
    console.log(paymentForm.value);
    if (paymentForm.value) {
      this.successMessage = 'Payment SuccessFul';
    }
  }
  ngOnInit() {
  }

}
