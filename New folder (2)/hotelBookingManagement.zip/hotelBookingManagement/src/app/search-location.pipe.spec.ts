import { SearchLocationPipe } from './search-location.pipe';

describe('SearchLocationPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchLocationPipe();
    expect(pipe).toBeTruthy();
  });
});
