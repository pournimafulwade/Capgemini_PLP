import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-userhotel',
  templateUrl: './view-userhotel.component.html',
  styleUrls: ['./view-userhotel.component.css']
})
export class ViewUserhotelComponent implements OnInit {

  hoteldetails: any[];
  localHotel = null;
  viewroom = null;
  viewroomdata = null;
  constructor(private hotelservice: HotelService, private roomservie: RoomService, private router: Router) {
    this.viewUserHotel();
  }

  viewUserHotel() {
    this.hotelservice.viewhotel().subscribe(data => {
      console.log(data);
      this.hoteldetails = data.hotelList;
    }, err => {
      console.log(err);
    });
  }

  searchHotel(search) {

    console.log(search.value);
    this.roomservie.getroom(search).subscribe(data => {
      this.hoteldetails = data.hotelList;
      console.log(this.hoteldetails);
    }, err => {
      console.log(err);
    });

  }

  searchuserHotel(location) {
    console.log(location.value);
    this.hotelservice.searchuserHotel(location).subscribe(data => {
      this.hoteldetails = data.hotelList;
      console.log(this.hoteldetails);
    });
  }

  bookRoom(roomdata) {
    console.log(roomdata);
    const room = localStorage.setItem('roomdetails', JSON.stringify(roomdata));
    this.router.navigateByUrl('/bookroom');

  }

  viewRoom(room) {
    this.router.navigateByUrl('/viewuserroom');
  }

  viewuserRoom(hoteldata) {
    console.log(hoteldata.hotelId);
    this.roomservie.viewroom(hoteldata.hotelId).subscribe(data => {
      this.viewroomdata = data.roomList;
      console.log(this.viewroomdata);
      const room = localStorage.setItem('roomdetails', JSON.stringify(data.roomList));
      this.router.navigateByUrl('/viewuserroom');
    });
  }

  bookroom(roomdata) {

  }

  hotel(hotelForm: NgForm) {
    this.roomservie.viewroom(hotelForm.value).subscribe(data => {
      console.log(data);
      this.viewroomdata = data.roomList;
      const hotels = localStorage.setItem('hoteldata', JSON.stringify('data.hotelList'));
      this.localHotel = hotels;
      console.log(hotels);
    });
  }


  ngOnInit() {
  }

}
