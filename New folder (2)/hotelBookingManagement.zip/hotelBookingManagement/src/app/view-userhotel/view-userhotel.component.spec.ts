import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewUserhotelComponent } from './view-userhotel.component';

describe('ViewUserhotelComponent', () => {
  let component: ViewUserhotelComponent;
  let fixture: ComponentFixture<ViewUserhotelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewUserhotelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewUserhotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
