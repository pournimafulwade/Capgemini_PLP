import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-book-room',
  templateUrl: './view-book-room.component.html',
  styleUrls: ['./view-book-room.component.css']
})
export class ViewBookRoomComponent implements OnInit {


  userDetails = null;
  viewroomdata = null;
  constructor(private roomservice: RoomService, private router: Router) {
    const userdata = JSON.parse(localStorage.getItem('userdata'));
    this.userDetails = userdata;
    console.log(this.userDetails);
    console.log(this.userDetails.userName);
    this.roomservice.viewUserRoom(this.userDetails.userName).subscribe(data => {
      console.log(data);
      this.viewroomdata = data.bookingList;
      const roomDetails = localStorage.setItem('roombooking', JSON.stringify(data));
      console.log(localStorage.getItem('roombooking'));
      console.log(this.viewroomdata);
    });

  }

  viewBookedRoom() {
    console.log(this.userDetails.userName);
    this.roomservice.viewUserRoom(this.userDetails.userName).subscribe(data => {
      console.log(data);
      this.viewroomdata = data.bookingList;
      console.log(this.viewroomdata);
    });
  }

  cancelBooking(roomdata) {
    this.roomservice.cancelRoom(roomdata.bookingId).subscribe(data => {
      console.log(data);
      this.router.navigateByUrl('/viewbookRoom');
      this.viewBookedRoom();
    });
  }

  ngOnInit() {
  }

}
