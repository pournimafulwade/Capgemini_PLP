import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBookRoomComponent } from './view-book-room.component';

describe('ViewBookRoomComponent', () => {
  let component: ViewBookRoomComponent;
  let fixture: ComponentFixture<ViewBookRoomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewBookRoomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewBookRoomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
