import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  url = `http://localhost:8080`;
  constructor(private http: HttpClient) { }

  addhotel(hotel): Observable<any> {
    return this.http.post<any>(`${this.url}/addHotel`, hotel);
  }
  viewhotel(): Observable<any> {
    return this.http.get<any>(`${this.url}/hotelList`);
  }
  deletehotel(hotel) {
    return this.http.delete(`${this.url}/deleteHotel?hotelId=${hotel.hotelId}`, hotel);
  }
  searchhotel(hotel): Observable<any> {
    return this.http.get<any>(`${this.url}/getRoom?hotelName=${hotel.hotelName}`, hotel);
  }
  searchuserHotel(location): Observable<any> {
    return this.http.get<any>(`${this.url}/getHotel?location=${location}`);
  }
  updatehotel(hotel): Observable<any> {
    return this.http.post<any>(`${this.url}/updateHotel`, hotel);
  }
}
