import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  error = null;
  errorMessage = null;
  successMessage = null;
  constructor(private userservice: UserService) { }

  registerEmployee(registerForm: NgForm) {
    console.log(registerForm.value);
    this.userservice.register(registerForm.value).subscribe(data => {
      console.log(data);
      if (data && data.statusCode === 201) {
        this.error = data.description;
        this.successMessage = 'Empoyee Registration Successful';
      } else if (data && data.statusCode === 401) {
        this.error = data.description;
        this.errorMessage = 'Employee Already Registered';
      }
      registerForm.reset();
    }, err => {
      console.log(err);
    });
  }


  ngOnInit() {
  }

}
