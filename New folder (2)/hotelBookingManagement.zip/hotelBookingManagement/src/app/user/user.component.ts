import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  viewprofile = null;
  constructor(private userservice: UserService) {
    const userDetails = JSON.parse(localStorage.getItem('userdata'));
    this.viewprofile = userDetails;
  }
  ngOnInit() {
  }

}
