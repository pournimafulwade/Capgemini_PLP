import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchLocation'
})
export class SearchLocationPipe implements PipeTransform {

  transform(hotels: any[], search: string): any[] {
    if (search === undefined) {
      return hotels;
    } else {
      return hotels.filter(hotel => {
        return (hotel.location as string).toLowerCase().includes(search.toLowerCase());
      });
    }
  }

}
