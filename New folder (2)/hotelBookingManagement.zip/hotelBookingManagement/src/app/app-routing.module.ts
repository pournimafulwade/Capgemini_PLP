import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { AddHotelComponent } from './add-hotel/add-hotel.component';
import { ViewHotelComponent } from './view-hotel/view-hotel.component';
import { ViewRoomComponent } from './view-room/view-room.component';
import { HomeComponent } from './home/home.component';
import { ViewUserhotelComponent } from './view-userhotel/view-userhotel.component';
import { ViewUserroomComponent } from './view-userroom/view-userroom.component';
import { ViewProfileComponent } from './view-profile/view-profile.component';
import { UserComponent } from './user/user.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { BookHotelComponent } from './book-hotel/book-hotel.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeHotelComponent } from './employee-hotel/employee-hotel.component';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { PaymentComponent } from './payment/payment.component';
import { ViewBookRoomComponent } from './view-book-room/view-book-room.component';
import { BookEmployeeComponent } from './book-employee/book-employee.component';
import { EmployeePaymentComponent } from './employee-payment/employee-payment.component';
import { ServicesComponent } from './services/services.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { BookinglistComponent } from './bookinglist/bookinglist.component';
import { GuestlistComponent } from './guestlist/guestlist.component';
import { DatelistComponent } from './datelist/datelist.component';
import { EmployeeStatusComponent } from './employee-status/employee-status.component';
import { VisitorComponent } from './visitor/visitor.component';


const routes: Routes = [
  { path: 'header', component: HeaderComponent },
  { path: '', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'user', component: UserComponent },
  { path: 'viewuser', component: ViewUserComponent },
  { path: 'viewemployee', component: ViewEmployeeComponent },
  { path: 'addhotel', component: AddHotelComponent },
  { path: 'viewhotel', component: ViewHotelComponent },
  { path: 'viewroom', component: ViewRoomComponent },
  { path: 'viewuserhotel', component: ViewUserhotelComponent },
  { path: 'viewuserroom', component: ViewUserroomComponent },
  { path: 'viewprofile', component: ViewProfileComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'userdashboard', component: UserDashboardComponent },
  { path: 'bookroom', component: BookHotelComponent },
  { path: 'employee', component: EmployeeComponent },
  { path: 'employeehotel', component: EmployeeHotelComponent },
  { path: 'employeeprofile', component: EmployeeProfileComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'viewbookRoom', component: ViewBookRoomComponent },
  { path: 'bookEmployeeroom', component: BookEmployeeComponent },
  { path: 'employeepayment', component: EmployeePaymentComponent },
  { path: 'services', component: ServicesComponent },
  { path: 'contactus', component: ContactUsComponent },
  { path: 'addEmployee', component: AddEmployeeComponent },
  { path: 'bookinglist', component: BookinglistComponent },
  { path: 'guestlist', component: GuestlistComponent },
  { path: 'datelist', component: DatelistComponent },
  { path: 'employeeStatus', component: EmployeeStatusComponent },
  { path: 'visitor', component: VisitorComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
