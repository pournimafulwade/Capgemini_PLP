import { Component, OnInit } from '@angular/core';
import { HotelService } from '../hotel.service';
import { RoomService } from '../room.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  hoteldetails: any[];
  localHotel = null;
  viewroom = null;
  viewroomdata = null;
  constructor(private hotelservice: HotelService, private roomservie: RoomService, private router: Router) {
    this.viewUserHotel();
  }

  viewUserHotel() {
    this.hotelservice.viewhotel().subscribe(data => {
      console.log(data);
      this.hoteldetails = data.hotelList;
    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
