package com.capgemini.hotelbookingmanagement.dao;

import java.util.List;

import com.capgemini.hotelbookingmanagement.beans.HotelBean;

public interface HotelDAO {
	public boolean addHotel(HotelBean hotelBean);

	public boolean removeHotel(int hotelId);

	public boolean updateHotel(HotelBean hotelBean);

	public List<HotelBean> getHotelList();
	
	public boolean removeHotel1(int hotelId);

}
