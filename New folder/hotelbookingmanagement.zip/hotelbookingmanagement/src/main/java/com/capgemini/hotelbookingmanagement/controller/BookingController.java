package com.capgemini.hotelbookingmanagement.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hotelbookingmanagement.beans.BookingBean;
import com.capgemini.hotelbookingmanagement.beans.HotelResponse;
import com.capgemini.hotelbookingmanagement.service.BookingService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials = "true")
public class BookingController {

	@Autowired
	private BookingService bookingService;
	boolean isAdded;

	public static final String SUCCESS = "success";
	public static final String FAILURE = "failed";

	@GetMapping(path = "/bookingList")
	public HotelResponse bookingListOfSpecificHotel() {
		List<BookingBean> bookingList = bookingService.bookingList();
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Booking details found");
			hotelResponse.setBookingList(bookingList);
		
		return hotelResponse;
	}// end of the bookingListOfSpecificHotel()

	@GetMapping(path = "/guestListOfSpecificHotel")
	public HotelResponse guestListOfSpecificHotel(int hotelId) {
		List<BookingBean> guestList = bookingService.guestListOfSpecificHotel(hotelId);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Guest list found");
			hotelResponse.setBookingList(guestList);
		
		return hotelResponse;
	}// end of the guestListOfSpecificHotel()

	@GetMapping(path = "/bookingListOnSpecificDate")
	public HotelResponse bookingListOnSpecificDate(@RequestParam("checkinDate/") Date checkinDate) {
		List<BookingBean> bookingList = bookingService.bookingListOnSpecificDate(checkinDate);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Guest list found");
			hotelResponse.setBookingList(bookingList);
		
		return hotelResponse;

	}// end of the bookingListOnSpecificDate()

	@GetMapping(path = "/viewStatus")
	public HotelResponse viewBookingStatus(String userName) {
		List<BookingBean> statusList = bookingService.viewBookingStatus(userName);
		HotelResponse hotelResponse = new HotelResponse();
		if (statusList != null) {
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Booking Status Found...");
			hotelResponse.setBookingList(statusList);
		} else {
			hotelResponse.setStatusCode(401);
			hotelResponse.setMessage(FAILURE);
			hotelResponse.setDescription("Booking Status not found...");
		}
		return hotelResponse;
	}

	@PutMapping(path = "/countOfDay")
	public HotelResponse countOfDay(@RequestParam String checkinDate, @RequestParam String checkoutDate) {
		float daysBetween = bookingService.countOfDay(checkinDate, checkoutDate);

		HotelResponse hotelResponse = new HotelResponse();
		if (daysBetween != 0) {
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Number of days generated...");
			hotelResponse.setDaysBetween(daysBetween);
		} else {
			hotelResponse.setStatusCode(401);
			hotelResponse.setMessage(FAILURE);
			hotelResponse.setDescription("Number of days cannot be genereated...");
		}
		return hotelResponse;
	}

	@PutMapping(path = "/booking")
	public HotelResponse booking(@RequestBody BookingBean bookingBean) {
		isAdded = bookingService.booking(bookingBean);
		HotelResponse hotelResponse = new HotelResponse();
	
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setBookingBean(bookingBean);
			hotelResponse.setDescription("booking done successful..!!");
	
		return hotelResponse;
	} // end of the booking()

	@PutMapping(path = "/bookingEmployee")
	public HotelResponse booking1(@RequestBody BookingBean bookingBean) {
		isAdded = bookingService.booking1(bookingBean);
		HotelResponse hotelResponse = new HotelResponse();
	
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("booking done successful..!!");
		
		return hotelResponse;
	}

	@GetMapping(path = "/totalBill")
	public HotelResponse totalBill(@RequestParam int roomId) {
		double bill = bookingService.bill(roomId);
	//	BookingBean bookingBean = new BookingBean();
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setPrice(bill);
			hotelResponse.setDescription("Total Amount to be Paid...");
		//	hotelResponse.setBookingBean(bookingBean);
		
		return hotelResponse;
	}
	
	@GetMapping(path = "/totalBill1")
	public HotelResponse totalBill1(@RequestParam int bookingId) {
		double bill = bookingService.totalBill(bookingId);
	//	BookingBean bookingBean = new BookingBean();
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setPrice(bill);
			hotelResponse.setDescription("Total Amount to be Paid...");
		//	hotelResponse.setBookingBean(bookingBean);
		
		return hotelResponse;
	}
	@DeleteMapping(path = "/deleteStatus")
	public HotelResponse deleteStatus(@RequestParam int bookingId) {
		boolean isDeleted = bookingService.deleteBookingStatus(bookingId);
		HotelResponse hotelResponse = new HotelResponse();
		if (isDeleted) {
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Status Delete");
		} else {
			hotelResponse.setStatusCode(401);
			hotelResponse.setMessage(FAILURE);
			hotelResponse.setDescription("Status is not Deleted");
		}
		return hotelResponse;
	}// end of the deleteRoom()
	
	

}
