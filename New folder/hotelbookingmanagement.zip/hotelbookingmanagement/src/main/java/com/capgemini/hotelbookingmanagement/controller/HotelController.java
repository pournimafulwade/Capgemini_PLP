package com.capgemini.hotelbookingmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hotelbookingmanagement.beans.HotelBean;
import com.capgemini.hotelbookingmanagement.beans.HotelResponse;
import com.capgemini.hotelbookingmanagement.service.HotelService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", allowCredentials = "true")
public class HotelController {
	@Autowired
	private HotelService hotelService;
	boolean isAdded;
	boolean isDeleted;
	boolean isUpdated;
	
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failed";
	
	
	@PostMapping(path = "/addHotel")
	public HotelResponse addHotel(@RequestBody HotelBean hotelBean) {
		 isAdded = hotelService.addHotel(hotelBean);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel Added successfully...");
			hotelResponse.setHotelBean1(hotelBean);
		
		return hotelResponse;
	}// end of the addHotel()
	
	@DeleteMapping(path = "/deleteHotel")
	public HotelResponse removeHotel(@RequestParam int hotelId) {
		isDeleted = hotelService.removeHotel(hotelId);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel get Deleted...");
		
		return hotelResponse;
	}// end of the removeHotel()
	@PostMapping(path = "/updateHotel")
	public HotelResponse updateHotel(@RequestBody HotelBean hotelBean) {
		isUpdated = hotelService.updateHotel(hotelBean);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel Details updated successfully...");
		
		return hotelResponse;
	}// end of the updateHotel()
	
	@GetMapping(path = "/hotelList")
	public HotelResponse hotelList() {
		List<HotelBean> hotelList = hotelService.getHotelList();
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel List found....");
			hotelResponse.setHotelList(hotelList);
		
		return hotelResponse;
	}// end of the hotelList()

	@GetMapping(path = "/getAllHotels")
	public HotelResponse getAllHotels() {
		List<HotelBean> hotelList = hotelService.getHotelList();
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel Data Found........");
			hotelResponse.setHotelList(hotelList);
		
		return hotelResponse;
	}// end of the getAllUsers()
	
	@DeleteMapping(path = "/deleteHotel1")
	public HotelResponse removeHotel1(@RequestParam int hotelId) {
		isDeleted = hotelService.removeHotel1(hotelId);
		HotelResponse hotelResponse = new HotelResponse();
		
			hotelResponse.setStatusCode(201);
			hotelResponse.setMessage(SUCCESS);
			hotelResponse.setDescription("Hotel get Deleted along with All Data...");
		
		return hotelResponse;
	}// end of the removeHotel()
}
