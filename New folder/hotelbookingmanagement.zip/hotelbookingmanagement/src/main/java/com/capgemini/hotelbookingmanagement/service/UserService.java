package com.capgemini.hotelbookingmanagement.service;

import java.util.List;

import com.capgemini.hotelbookingmanagement.beans.UserBean;

public interface UserService {
	public UserBean userLogin(String userEmail, String userPassword);

	public boolean userRegister(UserBean userBean);

	public boolean updateUserProfile(UserBean userBean);

	public int countOfUser(String userType);

	public List<UserBean> getAllUser();
	
	public List<UserBean> getAllEmployee();
}// end of the UserService interface
