package com.capgemini.hotelbookingmanagement.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.hotelbookingmanagement.beans.BookingBean;
import com.capgemini.hotelbookingmanagement.beans.HotelBean;
import com.capgemini.hotelbookingmanagement.beans.RoomBean;
import com.capgemini.hotelbookingmanagement.beans.UserBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;

@Repository
public class BookingDAOImplementation implements BookingDAO {
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory = Persistence
			.createEntityManagerFactory("hotelmanagementpersistence");
	BookingBean bookingBean = new BookingBean();

	@Override
	public List<BookingBean> bookingList() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			String jpql = "from BookingBean";
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			List<BookingBean> bookingList = null;
			bookingList = query.getResultList();
			entityTransaction.commit();
			return bookingList;
		} catch (Exception e) {
			throw new HotelException("Booking list not found..");
		}
	}

	@Override
	public List<BookingBean> guestListOfSpecificHotel(int hotelId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			String jpql = "from BookingBean where hotelId=: hotelId";
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			query.setParameter("hotelId", hotelId);
			List<BookingBean> guestList = null;
			guestList = query.getResultList();
			entityTransaction.commit();
			return guestList;
		} catch (Exception e) {
			throw new HotelException("There is no booking done for this particular hotel..");
		}
	}

	@Override
	public List<BookingBean> bookingListOnSpecificDate(Date checkinDate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			String jpql = "from BookingBean where checkinDate=:checkinDate";
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			query.setParameter("checkinDate", checkinDate);
			List<BookingBean> bookingList = null;
			bookingList = query.getResultList();
			entityTransaction.commit();
			return bookingList;
		} catch (Exception e) {
			throw new HotelException("There is no booking for the given date..");
		}
	}

//	@Override
//	public BookingBean viewBookingStatus(String userName) {
//		EntityManager entityManager = entityManagerFactory.createEntityManager();
//		try {
//			String jpql = "from BookingBean where userName =: userName";
//			Query query = entityManager.createQuery(jpql);
//			query.setParameter("userName", userName);
//			BookingBean bookingBean = (BookingBean) query.getSingleResult();
//			entityManager.close();
//			return bookingBean;
//		} catch (Exception e) {
//			throw new HotelException("No status found..");
//		}
//	}

	@Override
	public float countOfDay(String checkinDate, String checkoutDate) {
		float daysBetween = 0;
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date dateBefore = myFormat.parse(checkinDate);
			Date dateAfter = myFormat.parse(checkoutDate);
			long difference = dateAfter.getTime() - dateBefore.getTime();
			daysBetween = (difference / (1000 * 60 * 60 * 24));
		} catch (Exception e) {
			throw new HotelException("Count of days not found...");
		}
		return daysBetween + 1;

	}

	@Override
	public boolean booking(BookingBean bookingBean) {
		double roomRent = 0;
		String hotelName = null;
		String userName = null;
		Date checkinDate;
		Date checkoutDate;
		String modeOfPayment = null;
		String paymentStatus = null;
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = null;
		boolean isadd = false;
		float daysBetween = 0;
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			transaction = entityManager.getTransaction();

			String jpql = "from UserBean where userId=:userId";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("userId", bookingBean.getUserId());
			UserBean userBean = (UserBean) query.getSingleResult();
			userName = userBean.getUserName();

			String jpql1 = "from HotelBean where hotelId=:hotelId";
			Query query1 = entityManager.createQuery(jpql1);
			query1.setParameter("hotelId", bookingBean.getHotelId());
			HotelBean hotelBean = (HotelBean) query1.getSingleResult();
			hotelName = hotelBean.getHotelName();

			String jpql2 = "from RoomBean where roomId=:roomId";
			Query query2 = entityManager.createQuery(jpql2);
			query2.setParameter("roomId", bookingBean.getRoomId());
			RoomBean roomBean = (RoomBean) query2.getSingleResult();
			roomRent = roomBean.getRoomRent();

			Date dateBefore = bookingBean.getCheckinDate();
			Date dateAfter = bookingBean.getCheckoutDate();
			if (dateAfter.getTime() >= dateBefore.getTime()) {
				long difference = dateAfter.getTime() - dateBefore.getTime();
				daysBetween = (difference / (1000 * 60 * 60 * 24));

				bookingBean.setRoomRent(roomRent);
				bookingBean.setHotelName(hotelName);
				bookingBean.setTotalDays((int) daysBetween + 1);
				bookingBean.setUserName(userName);

				transaction.begin();
				entityManager.persist(bookingBean);
				System.out.println("booking done!");
				transaction.commit();
				isadd = true;
			} else {
				throw new HotelException("Please Provide valid Date");
			}

		} catch (Exception e) {

			throw new HotelException("Please Provide valid Date");
		}
		return isadd;
	}

	@Override
	public boolean booking1(BookingBean bookingBean) {
		double roomRent = 0;
		String hotelName = null;
		Date checkinDate;
		Date checkoutDate;
		String modeOfPayment = null;
		String paymentStatus = null;
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = null;
		boolean isadd = false;
		float daysBetween = 0;
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			transaction = entityManager.getTransaction();

			String jpql = "from UserBean where userId=:userId";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("userId", bookingBean.getUserId());
			UserBean userBean = (UserBean) query.getSingleResult();

			String jpql1 = "from UserBean where hotelId=:hotelId";
			Query query1 = entityManager.createQuery(jpql1);
			query1.setParameter("hotelId", bookingBean.getHotelId());
			HotelBean hotelBean = (HotelBean) query1.getSingleResult();
			hotelName = hotelBean.getHotelName();

			String jpql2 = "from RoomBean where roomId=:roomId";
			Query query2 = entityManager.createQuery(jpql2);
			query2.setParameter("roomId", bookingBean.getRoomId());
			RoomBean roomBean = (RoomBean) query2.getSingleResult();
			roomRent = roomBean.getRoomRent();

			Date dateBefore = bookingBean.getCheckinDate();
			Date dateAfter = bookingBean.getCheckoutDate();
			long difference = dateAfter.getTime() - dateBefore.getTime();
			daysBetween = (difference / (1000 * 60 * 60 * 24));

			bookingBean.setRoomRent(roomRent);
			bookingBean.setHotelName(hotelName);
			bookingBean.setTotalDays((int) daysBetween);

			transaction.begin();
			entityManager.persist(bookingBean);
			System.out.println("booking done!");
			transaction.commit();
			isadd = true;

		} catch (Exception e) {
			throw new HotelException("Unavailable to Book ");
		}
		return isadd;
	}

	@Override
	public double bill(int roomId) {
		double bill = 0;
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			String jpql = "from BookingBean where roomId=:roomId";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("roomId", roomId);
			BookingBean bookingBean = (BookingBean) query.getSingleResult();
			Date dateBefore = bookingBean.getCheckinDate();
			Date dateAfter = bookingBean.getCheckoutDate();
			long difference = dateAfter.getTime() - dateBefore.getTime();
			float daysBetween = (difference / (1000 * 60 * 60 * 24));
			bill = daysBetween * bookingBean.getRoomRent();
			return bill;
		} catch (Exception e) {
			// throw new HotelException("Billing not possible ");
			e.printStackTrace();
		}
		return bill;
	}

	@Override
	public double totalBill(int bookingId) {
		double bill = 0;
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			String jpql = "from BookingBean where bookingId=:bookingId";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("bookingId", bookingId);
			BookingBean bookingBean = (BookingBean) query.getSingleResult();
			Date dateBefore = bookingBean.getCheckinDate();
			Date dateAfter = bookingBean.getCheckoutDate();
			long difference = dateAfter.getTime() - dateBefore.getTime();
			float daysBetween = (difference / (1000 * 60 * 60 * 24));
			float a = daysBetween + 1;
			bill = a * bookingBean.getRoomRent();
			return bill;
		} catch (Exception e) {
			throw new HotelException("Billing not possible ");
//			e.printStackTrace();
		}
	}

	@Override
	public List<BookingBean> viewBookingStatus(String userName) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			String jpql = "from BookingBean where userName =: userName";
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			query.setParameter("userName", userName);
			List<BookingBean> statusList = null;
			statusList= query.getResultList();
			entityTransaction.commit();
			return statusList;
		} catch (Exception e) {
			throw new HotelException("No status found..");
		}
	}

	@Override
	public boolean deleteBookingStatus(int bookingId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		boolean isDeleted = false;

		try {
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			BookingBean bookingBean = entityManager.find(BookingBean.class, bookingId);
			entityManager.remove(bookingBean);
			entityTransaction.commit();
			isDeleted = true;

		} catch (Exception e) {
			throw new HotelException("Status deleted..");
		}
		entityManager.close();
		return isDeleted;
	}

}
