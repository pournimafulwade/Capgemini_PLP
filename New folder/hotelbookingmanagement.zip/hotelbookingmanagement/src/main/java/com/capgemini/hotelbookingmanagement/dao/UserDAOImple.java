package com.capgemini.hotelbookingmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.hotelbookingmanagement.beans.UserBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;

@Repository
public class UserDAOImple implements UserDAO {
	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory = Persistence
			.createEntityManagerFactory("hotelmanagementpersistence");

	@Override
	public UserBean userLogin(String userEmail, String userPassword) {
		UserBean userBean = null;
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		try {
			String jpql = "from UserBean where userEmail = :userEmail and userPassword = :userPassword ";
			Query query = entityManager.createQuery(jpql);
			query.setParameter("userEmail", userEmail);
			query.setParameter("userPassword", userPassword);
			userBean = (UserBean) query.getSingleResult();
		} catch (Exception e) {
			throw new HotelException("Enter valid credentials");
		}
		return userBean;
	}// end of the userLogin()

	@Override
	public boolean userRegister(UserBean userBean) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isAdded = false;
		try {
			transaction.begin();
			entityManager.persist(userBean);
			transaction.commit();
			isAdded = true;
		} catch (Exception e) {
			throw new HotelException("Unable to Register");
		}
		entityManager.close();
		return isAdded;
	}// end of the userRegister()

	@Override
	public boolean updateUserProfile(UserBean userBean) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		UserBean userBean1 = entityManager.find(UserBean.class, userBean.getUserId());
		boolean isUpdate = false;
		if (userBean1 != null) {
			String userPassword = userBean.getUserPassword();
			if (userPassword != null) {
				userBean1.setUserPassword(userPassword);
			}
			String address = userBean.getAddress();
			if (address != null) {
				userBean1.setAddress(address);
			}
			String mobile = userBean.getMobile();
			if (mobile != null) {
				userBean1.setMobile(mobile);
			}
		}
		try {
			entityTransaction.begin();
			entityManager.persist(userBean1);
			entityTransaction.commit();
			isUpdate = true;
		} catch (Exception e) {
			throw new HotelException("Unable to Update the User Profile");
		}
		entityManager.close();
		return isUpdate;
	}// end of the updateUserProfile()

	@Override
	public int countOfUser(String userType) {
		int count = 0;

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		List<UserBean> userList = null;
		String jpql = "from UserBean where userType=:userType";
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		Query query = entityManager.createQuery(jpql);
		query.setParameter("userType", userType);
		userList = query.getResultList();
		for (UserBean userBean : userList) {
			System.out.println("-------------" + userBean.getUserId());
			count++;
		}
		entityTransaction.commit();
		entityManager.close();
		return count;
	}

	@Override
	public List<UserBean> getAllUser() {
		EntityManager manager = entityManagerFactory.createEntityManager();
		String jpql = "from UserBean where userType = 'user'";
		Query query = manager.createQuery(jpql);

		List<UserBean> userList = null;
		try {
			userList = query.getResultList();
		} catch (Exception e) {
			throw new HotelException("Unable to get all Users");
		}
		return userList;
	}

	@Override
	public List<UserBean> getAllEmployee() {
		EntityManager manager = entityManagerFactory.createEntityManager();
		String jpql = "from UserBean where userType ='employee'";
		Query query = manager.createQuery(jpql);

		List<UserBean> employeeList = null;
		try {
			employeeList = query.getResultList();
		} catch (Exception e) {
			throw new HotelException("Unable to get All Employee List");
		}
		return employeeList;
	}

}// end of the userDAOImple class
