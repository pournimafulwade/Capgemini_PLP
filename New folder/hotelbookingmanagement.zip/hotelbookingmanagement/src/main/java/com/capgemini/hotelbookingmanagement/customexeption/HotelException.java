package com.capgemini.hotelbookingmanagement.customexeption;

@SuppressWarnings("serial")
public class HotelException extends RuntimeException {
	String message;
	public HotelException(String message) {
		super();
		this.message=message;
	}
	
	@Override
	public String getMessage() {
		return message;
	}
}//end of the class HotelException
