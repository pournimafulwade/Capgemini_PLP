package com.capgemini.hotelbookingmanagement.service;

import java.util.List;

import com.capgemini.hotelbookingmanagement.beans.HotelBean;

public interface HotelService {
	public boolean addHotel(HotelBean hotelBean);

	public boolean removeHotel(int hotelId);

	public boolean updateHotel(HotelBean hotelBean);

	public List<HotelBean> getHotelList();
	
	public boolean removeHotel1(int hotelId);

	//List<HotelBean> getAllHotel();

}
