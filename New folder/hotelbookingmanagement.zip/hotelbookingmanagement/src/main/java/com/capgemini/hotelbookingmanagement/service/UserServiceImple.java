package com.capgemini.hotelbookingmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hotelbookingmanagement.beans.UserBean;
import com.capgemini.hotelbookingmanagement.dao.UserDAO;

@Service
public class UserServiceImple implements UserService {
	@Autowired
	private UserDAO userDAO;

	@Override
	public UserBean userLogin(String userEmail, String userPassword) {
		return userDAO.userLogin(userEmail, userPassword);
	}

	@Override
	public boolean userRegister(UserBean userBean) {
		return userDAO.userRegister(userBean);
	}

	@Override
	public boolean updateUserProfile(UserBean userBean) {
		return userDAO.updateUserProfile(userBean);
	}

	@Override
	public int countOfUser(String userType) {
		return userDAO.countOfUser(userType);
	}

	@Override
	public List<UserBean> getAllUser() {
		return userDAO.getAllUser();
	}

	@Override
	public List<UserBean> getAllEmployee() {
		return userDAO.getAllEmployee();
	}


}// end of the UserServiceImple class
