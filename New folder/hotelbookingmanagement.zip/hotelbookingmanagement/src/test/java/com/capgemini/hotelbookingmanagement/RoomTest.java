package com.capgemini.hotelbookingmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.hotelbookingmanagement.beans.RoomBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;
import com.capgemini.hotelbookingmanagement.dao.RoomDAOImplementation;

@SpringBootTest
public class RoomTest {
	@Autowired
	RoomDAOImplementation roomDAOImplementation;
	RoomBean roomBean = new RoomBean();
	
	@Test
	public void testAddRoom() {
		roomBean.setHotelId(3);
		roomBean.setRoomCapacity(2);
		roomBean.setRoomRent(3999.00);
		roomBean.setRoomType("AC");
		roomBean.setRoomStatus("Available");
		boolean addRoom = roomDAOImplementation.addRoom(roomBean);
		assertEquals(true, addRoom);
	}
	
	@Test
	public void testAddRoomInvalid() {
		roomBean.setHotelId(3);
		roomBean.setRoomCapacity(8);
		roomBean.setRoomRent(3999.00);
		roomBean.setRoomType("AC");
		roomBean.setRoomStatus("Available");
		assertThrows(HotelException.class, () -> {
			roomDAOImplementation.addRoom(roomBean);
		});
	}
	
	@Test
	public void testDeleteRoom() {
		boolean deleteRoom = roomDAOImplementation.deleteHotelRoom(2);
		assertEquals(true, deleteRoom);
	}
	
	@Test
	public void testDeleteRoomInvalid() {
		assertThrows(HotelException.class, () -> {
			roomDAOImplementation.deleteRoom(2);
		});
	}
	
	@Test
	public void testUpdateRoom() {
		roomBean.setRoomId(2);
		roomBean.setRoomCapacity(3);
		roomBean.setRoomType("Non-AC");
		roomBean.setRoomStatus("Available");
		roomBean.setRoomRent(4999.00);
		boolean updateRoom = roomDAOImplementation.updateRoom(roomBean);
		assertEquals(true, updateRoom);
	}
	
	@Test
	public void testUpdateRoomInvalid() {
		roomBean.setRoomId(2);
		roomBean.setRoomRent(4999.00);
		roomBean.setRoomCapacity(3);
		roomBean.setRoomType("AC");
		roomBean.setRoomStatus("Available");
		assertThrows(HotelException.class, () -> {
			roomDAOImplementation.updateRoom(roomBean);
		});
	}
	
	@Test
	public void testDeleteHotelRoom() {
		boolean deleteHotelRoom = roomDAOImplementation.deleteHotelRoom(3);
		assertEquals(true, deleteHotelRoom);
	}
	
	@Test
	public void testDeleteHotelRoomInvalid() {
		assertThrows(HotelException.class, () -> {
			roomDAOImplementation.deleteHotelRoom(3);
		});
	}

}
