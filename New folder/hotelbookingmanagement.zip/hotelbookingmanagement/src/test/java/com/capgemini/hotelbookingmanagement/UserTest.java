package com.capgemini.hotelbookingmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.hotelbookingmanagement.beans.UserBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;
import com.capgemini.hotelbookingmanagement.dao.UserDAOImple;

@SpringBootTest
public class UserTest {
	@Autowired
	UserDAOImple userDAOImple;
	UserBean userBean = new UserBean();  
	
	@Test
	public void testUserRegister() {
		userBean.setUserName("qwerty");
		userBean.setUserEmail("qwerty@gmail.com");
		userBean.setUserPassword("Qwerty07");
		userBean.setAddress("Chennai");
		userBean.setNationality("Indian");
		userBean.setMobile("7894564562");
		userBean.setUserType("user");
		boolean userRegister = userDAOImple.userRegister(userBean);
		assertEquals(true, userRegister);
	}
	
	@Test
	public void testUserRegisterInvalid() {
		userBean.setUserName("asdf");
		userBean.setUserEmail("asdf@gmail.com");
		userBean.setUserPassword("Asdf12345");
		userBean.setMobile("9876543210");
		userBean.setAddress("Maharashtra");
		userBean.setNationality("Indian");
		userBean.setUserType("user");
		assertThrows(HotelException.class, () -> {
			userDAOImple.userRegister(userBean);
		});
	}
	
	@Test
	public void testUpdateUserDetails() {
		userBean.setUserId(3);
		userBean.setAddress("Chennai");
		userBean.setMobile("7412589630");
		userBean.setUserPassword("Shubham12345");
		boolean updateUserProfile = userDAOImple.updateUserProfile(userBean);
		assertEquals(true, updateUserProfile);
	}
	
	@Test
	public void testUpdateUserProfileInvalid() {
		userBean.setUserId(4);
		userBean.setAddress("punjab");
		userBean.setMobile("qwerty");
		userBean.setUserPassword("Amruta1234");
		assertThrows(HotelException.class, () -> {
		userDAOImple.updateUserProfile(userBean);
		});
	}
	
	@Test
	public void testCountOfUser() {
		int count = userDAOImple.countOfUser("user");
		assertEquals(true, count);
	}
	
	@Test
	public void testCountOfUserInvalid() {
		assertThrows(HotelException.class, () -> {
			userDAOImple.countOfUser("user");
		});
	}
}
