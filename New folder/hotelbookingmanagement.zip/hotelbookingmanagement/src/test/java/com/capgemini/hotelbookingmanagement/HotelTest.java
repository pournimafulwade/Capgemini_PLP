package com.capgemini.hotelbookingmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.hotelbookingmanagement.beans.HotelBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;
import com.capgemini.hotelbookingmanagement.dao.HotelDAOImplementation;

@SpringBootTest
public class HotelTest {
	
	@Autowired
	HotelDAOImplementation hotelDAOImplementation;
	HotelBean hotelBean = new HotelBean();
	
	@Test
	public void testAddHotel() {
		hotelBean.setHotelName("Raaj");
		hotelBean.setLocation("Karnataka");
		hotelBean.setLocation("https://cdn.pixabay.com/photo/2015/09/28/21/32/the-palm-962785__340.jpg");
		boolean addHotel = hotelDAOImplementation.addHotel(hotelBean);
		assertEquals(true, addHotel);
	}
	
	@Test
	public void testAddHotelInvalid() {
		hotelBean.setHotelName("prajyot");
		hotelBean.setLocation("qwerty");
		hotelBean.setLocation("https://cdn.pixabay.com/photo/2016/11/18/22/21/architecture-1837150__340.jpg");
		assertThrows(HotelException.class, () -> {
			hotelDAOImplementation.addHotel(hotelBean);
		});
	}
	
	@Test 
	public void testDeleteHotel() {
		boolean deleteHotel = hotelDAOImplementation.removeHotel(8);
		assertEquals(true, deleteHotel);
	}
	
	@Test
	public void testDeleteHotelInvalid() {
		assertThrows(HotelException.class,  () -> {
			hotelDAOImplementation.removeHotel(7);
		});
	}
	
	@Test
	public void testUpdateHotel() {
		hotelBean.setHotelId(4);
		hotelBean.setHotelName("Sagar");
		hotelBean.setLocation("Nagpur");
		boolean updateHotel = hotelDAOImplementation.updateHotel(hotelBean);
		assertEquals(true, updateHotel);
	}
	
	@Test
	public void testUpdateHotelInvalid() {
		hotelBean.setHotelId(4);
		hotelBean.setHotelName("Chhootu");
		hotelBean.setLocation("Mumbai");
		assertThrows(HotelException.class, () -> {
		hotelDAOImplementation.updateHotel(hotelBean);
		});
	}

}
