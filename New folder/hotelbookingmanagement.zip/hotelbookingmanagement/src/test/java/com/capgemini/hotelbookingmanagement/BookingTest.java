package com.capgemini.hotelbookingmanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.hotelbookingmanagement.beans.BookingBean;
import com.capgemini.hotelbookingmanagement.customexeption.HotelException;
import com.capgemini.hotelbookingmanagement.dao.BookingDAOImplementation;

@SpringBootTest
public class BookingTest {
	@Autowired
	BookingDAOImplementation bookingDAOImplementation;
	BookingBean bookingBean = new BookingBean();
	
//	@Test
//	public void testViewBookingStatus() {
//		
//		BookingBean status = bookingDAOImplementation.viewBookingStatus("Kartik");
//		assertEquals(true, status);
//	}
	
	@Test
	public void testViewBookingStatusInvalid() {
		assertThrows(HotelException.class, () -> {
			bookingDAOImplementation.viewBookingStatus("kartik tyagi");
		});
	}
	
	@Test
	public void testCountDay() {
		float countDay = bookingDAOImplementation.countOfDay("2019-12-25", "2019-12-30");
		assertEquals(6.0, countDay);
	}
	
	@Test
	public void testCountDayInvalid() {
		assertThrows(HotelException.class, () -> {
			bookingDAOImplementation.countOfDay("2019-12-25", "2019-12-30");
		});
	}
	
//	@Test
//	public void testBooking() {
//		bookingBean.setUserId(2);
//		bookingBean.setHotelId(2);
//		bookingBean.setRoomId(2);
//		bookingBean.setRoomRent(2999.00);
//		bookingBean.setCheckinDate("2019-12-30");
//		bookingBean.setCheckoutDate("2019-12-28");
//		boolean booking = bookingDAOImplementation.booking(bookingBean);
//		assertEquals(true, booking);
//	}
	
//	@Test
//	public void testBookingInvalid() {
//		bookingBean.setUserId(2);
//		bookingBean.setHotelId(2);
//		bookingBean.setRoomId(2);
//		bookingBean.setRoomRent(3999.00);
//		bookingBean.setCheckinDate("2019 12 25");
//		bookingBean.setCheckoutDate("2019 12 30");
//		assertThrows(HotelException.class, () -> {
//			bookingDAOImplementation.booking(bookingBean);
//		});
//	}
	
//	@Test
//	public void testBooking1() {
//		bookingBean.setUserId(3);
//		bookingBean.setHotelId(3);
//		bookingBean.setRoomId(2);
//		bookingBean.setRoomRent(4999.00);
//		bookingBean.setCheckinDate("2019 12 27");
//		bookingBean.setCheckoutDate("2019 12 29");
//		boolean booking = bookingDAOImplementation.booking1(bookingBean);
//		assertEquals(true, booking);
//	}

//	@Test
//	public void testBooking1Invalid() {
//		bookingBean.setUserId(3);
//		bookingBean.setHotelId(3);
//		bookingBean.setRoomId(2);
//		bookingBean.setRoomRent(4999.00);
//		bookingBean.setCheckinDate("2019 12 27");
//		bookingBean.setCheckoutDate("2019 12 29");
//		assertThrows(HotelException.class, () -> {
//			bookingDAOImplementation.booking1(bookingBean);
//		});
//	}
	
	@Test
	public void testBill() {
		double bill = bookingDAOImplementation.bill(2);
		assertEquals(true, bill);
	}
	
	@Test
	public void testBillInvalid() {
	
		assertThrows(HotelException.class, () -> {
			bookingDAOImplementation.bill(2);
		});
	}

}
